package Fun_Alphabet;
import java.io.File;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import static javax.sound.sampled.AudioSystem.getAudioInputStream;

public class classA {
    JFrame frameObjA;
    JLabel l = new JLabel();

    JLabel l2 = new JLabel();
    JLabel l1 = new JLabel("۱");

    classA(){
        frameObjA = new JFrame();
        Container C2 = frameObjA.getContentPane();
        C2.setBackground(new Color(166, 65, 217, 255));
        frameObjA.setExtendedState(Frame.MAXIMIZED_BOTH);
        frameObjA.setLayout(null);
        frameObjA.setSize(1540, 820);
        frameObjA.setTitle("FUN ALPHABET");
        frameObjA.setSize(new Dimension(1540, 820));
        frameObjA.setUndecorated(false);
        frameObjA.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 16, 35, 16, Color.white));
        frameObjA.setVisible(true);


        JLabel l3 = new JLabel("اک");
        l3.setForeground(Color.black);
        l3.setFont(new Font("Arial", Font.BOLD, 200));
        l3.setBounds(880,0,350,270);
        l3.setVisible(true);
        C2.add(l3);

        JLabel l4 = new JLabel("انب");
        l4.setForeground(Color.black);
        l4.setFont(new Font("Arial", Font.BOLD, 200));
        l4.setBounds(280,0,350,270);
        l4.setVisible(true);
        C2.add(l4);

        l1.setForeground(Color.black);
        l1.setFont(new Font("Arial", Font.BOLD, 280));
        l1.setBounds(1300,250,200,400);
        l1.setVisible(true);
        C2.add(l1);


        l.setBounds(800, 290, 400, 300);
        l.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\1.jpeg"));
        l.setVisible(true);
        C2.add(l);

        l2.setBounds(200, 290, 400, 300);
        l2.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\a.jpg"));
        l2.setVisible(true);
        C2.add(l2);

        JButton music = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music.setFont(new Font("Arial", Font.BOLD, 18));
        music.setBounds(800, 600, 30, 30);
        frameObjA.add(music);

        music.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\1.wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });

        JButton music2 = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music2.setFont(new Font("Arial", Font.BOLD, 18));
        music2.setBounds(200, 600, 30, 30);
        frameObjA.add(music2);

        music2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\1(1).wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });

        JButton back = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\home_btn.png"));
        back.setFont(new Font("Arial", Font.BOLD, 18));
        back.setBounds(25, 20, 60, 60);
        frameObjA.add(back);

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjA.dispose();
                new Fun_Alphabet();
            }
        });

        JButton previous = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\previous.jpg"));
        previous.setFont(new Font("Arial", Font.BOLD, 18));
        previous.setBounds(200, 690, 150, 60);
        frameObjA.add(previous);

        JButton next = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\next.jpg"));
        next.setFont(new Font("Arial", Font.BOLD, 18));
        next.setBounds(1050, 690, 150, 60);
        frameObjA.add(next);

        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjA.dispose();
                new classB();
            }
        });

    }
}
