package Fun_Alphabet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Fun_Alphabet {

            Fun_Alphabet(){
            JFrame loginFrame = new JFrame();
            loginFrame.setSize(1540, 820);
            loginFrame.setExtendedState(Frame.MAXIMIZED_BOTH);
            loginFrame.setTitle("FUN ALPHABET");
            loginFrame.setLayout(null);
            loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Container c = loginFrame.getContentPane();
            c.setBackground(new Color(166, 65, 217, 255));
            loginFrame.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 20, 35, 20, Color.white));

            JLabel heading = new JLabel("FUN ALPHABET");
            heading.setBounds(520, 50, 860, 100);
            heading.setFont(new Font("Algerian", Font.BOLD, 64));
            heading.setForeground(Color.WHITE);
            loginFrame.add(heading);


            JLabel l1 = new JLabel();
            l1.setBounds(30, 180, 430, 430);
            l1.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\e1.jpg"));
            l1.setVisible(true);
            c.add(l1);

            JLabel l2 = new JLabel();
            l2.setBounds(540, 180, 430, 430);
            l2.setIcon(new ImageIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\urdu.jpg")
                    .getImage().getScaledInstance(430, 430, Image.SCALE_DEFAULT)));
            l2.setVisible(true);
            c.add(l2);


            JLabel l3 = new JLabel();
            l3.setBounds(1050, 180, 430, 430);
            l3.setIcon(new ImageIcon((new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\sindhi.jpg")
                    .getImage().getScaledInstance(430, 430, Image.SCALE_DEFAULT))));
            l3.setVisible(true);
            c.add(l3);


            JButton englishButton = new JButton("ENGLISH");
            englishButton.setFont(new Font("Arial", Font.ITALIC, 40));
            englishButton.setBounds(45, 630, 400, 80);
            loginFrame.add(englishButton);


            JButton urduButton = new JButton("URDU");
            urduButton.setFont(new Font("Arial", Font.ITALIC, 40));
            urduButton.setBounds(555, 630, 400, 80);
            loginFrame.add(urduButton);

            JButton sindhiButton = new JButton("SINDHI");
            sindhiButton.setFont(new Font("Arial", Font.ITALIC, 40));
            sindhiButton.setBounds(1065, 630, 400, 80);
            loginFrame.add(sindhiButton);


            sindhiButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    loginFrame.dispose();
                    new layout();
                }
            });

            englishButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    englishButton.setText("COMING SOON");
                }
            });

            urduButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    urduButton.setText("COMING SOON");
                }
            });
            loginFrame.setVisible(true);
            }

    public static void main(String[] args) {
        new Fun_Alphabet();
    }
}

