package Fun_Alphabet;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import static javax.sound.sampled.AudioSystem.getAudioInputStream;

public class classX {

    JFrame frameObjX;
    JLabel l2 = new JLabel();
    JLabel l = new JLabel();
    JLabel l1 = new JLabel("ذ");

    classX(){
        frameObjX = new JFrame();
        Container C2 = frameObjX.getContentPane();
        C2.setBackground(new Color(166, 65, 217, 255));
        frameObjX.setLayout(null);
        frameObjX.setExtendedState(Frame.MAXIMIZED_BOTH);
        frameObjX.setSize(1540, 820);
        frameObjX.setTitle("FUN ALPHABET");
        frameObjX.setSize(new Dimension(1540, 820));
        frameObjX.setUndecorated(false);
        frameObjX.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 16, 35, 16, Color.white));
        frameObjX.setVisible(true);

        l1.setForeground(Color.black);
        l1.setFont(new Font("Arial", Font.BOLD, 280));
        l1.setBounds(1250,230,150,390);
        l1.setVisible(true);
        C2.add(l1);


        l.setBounds(780, 220, 400, 400);
        l.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\24.jpeg"));
        l.setVisible(true);
        C2.add(l);


        JLabel l3 = new JLabel("ذخيرو");
        l3.setForeground(Color.black);
        l3.setFont(new Font("Arial", Font.BOLD, 180));
        l3.setBounds(820,0,380,230);
        l3.setVisible(true);
        C2.add(l3);

        JLabel l4 = new JLabel("ذرو");
        l4.setForeground(Color.black);
        l4.setFont(new Font("Arial", Font.BOLD, 180));
        l4.setBounds(280,0,380,230);
        l4.setVisible(true);
        C2.add(l4);

        JButton music = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music.setFont(new Font("Arial", Font.BOLD, 18));
        music.setBounds(780, 630, 30, 30);
        frameObjX.add(music);

        music.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\24.wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });

        JButton music2 = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music2.setFont(new Font("Arial", Font.BOLD, 18));
        music2.setBounds(180, 630, 30, 30);
        frameObjX.add(music2);

        music2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\24(1).wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });

        JButton previous = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\previous.jpg"));
        previous.setFont(new Font("Arial", Font.BOLD, 18));
        previous.setBounds(180, 690, 150, 60);
        frameObjX.add(previous);

        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjX.dispose();
                new classY();
            }
        });

        JButton next = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\next.jpg"));
        next.setFont(new Font("Arial", Font.BOLD, 18));
        next.setBounds(1030, 690, 150, 60);
        frameObjX.add(next);

        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjX.dispose();
                new classW();
            }
        });

        l2.setBounds(180, 220, 400, 400);
        l2.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\x.jpg"));
        l2.setVisible(true);
        C2.add(l2);

        JButton back = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\home_btn.png"));
        back.setFont(new Font("Arial", Font.BOLD, 18));
        back.setBounds(25, 20, 60, 60);
        frameObjX.add(back);

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjX.dispose();
                new Fun_Alphabet();
            }
        });
    }
}
