package Fun_Alphabet;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import static javax.sound.sampled.AudioSystem.getAudioInputStream;

public class classE {

    JFrame frameObjE;
        JLabel l2 = new JLabel();
    JLabel l = new JLabel();
    JLabel l1 = new JLabel("ت");

    classE(){
        frameObjE = new JFrame();
        Container C2 = frameObjE.getContentPane();
        C2.setBackground(new Color(166, 65, 217, 255));
        frameObjE.setExtendedState(Frame.MAXIMIZED_BOTH);
        frameObjE.setLayout(null);
        frameObjE.setSize(1540, 820);
        frameObjE.setTitle("FUN ALPHABET");
        frameObjE.setSize(new Dimension(1540, 820));
        frameObjE.setUndecorated(false);
        frameObjE.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 16, 35, 16, Color.white));
        frameObjE.setVisible(true);

        JLabel l3 = new JLabel("تارو");
        l3.setForeground(Color.black);
        l3.setFont(new Font("Arial", Font.BOLD, 180));
        l3.setBounds(880,0,380,250);
        l3.setVisible(true);
        C2.add(l3);

        JLabel l4 = new JLabel("تالو");
        l4.setForeground(Color.black);
        l4.setFont(new Font("Arial", Font.BOLD, 180));
        l4.setBounds(280,0,380,250);
        l4.setVisible(true);
        C2.add(l4);

        l1.setForeground(Color.black);
        l1.setFont(new Font("Arial", Font.BOLD, 280));
        l1.setBounds(1220,230,190,390);
        l1.setVisible(true);
        C2.add(l1);


        l.setBounds(780, 220, 400, 400);
        l.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\5.jpg"));
        l.setVisible(true);
        C2.add(l);

        l2.setBounds(180, 220, 400, 400);
        l2.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\e.jpg"));
        l2.setVisible(true);
        C2.add(l2);

        JButton music = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music.setFont(new Font("Arial", Font.BOLD, 18));
        music.setBounds(780, 630, 30, 30);
        frameObjE.add(music);

        JButton music2 = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music2.setFont(new Font("Arial", Font.BOLD, 18));
        music2.setBounds(180, 630, 30, 30);
        frameObjE.add(music2);

        music2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\5(1).wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });


        JButton previous = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\previous.jpg"));
        previous.setFont(new Font("Arial", Font.BOLD, 18));
        previous.setBounds(180, 690, 150, 60);
        frameObjE.add(previous);

        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjE.dispose();
                new classF();
            }
        });

        JButton next = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\next.jpg"));
        next.setFont(new Font("Arial", Font.BOLD, 18));
        next.setBounds(1030, 690, 150, 60);
        frameObjE.add(next);

        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjE.dispose();
                new classD();
            }
        });

        JButton back = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\home_btn.png"));
        back.setFont(new Font("Arial", Font.BOLD, 18));
        back.setBounds(25, 20, 60, 60);
        frameObjE.add(back);

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjE.dispose();
                new Fun_Alphabet();
            }
        });
    }
}
