package Fun_Alphabet;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import static javax.sound.sampled.AudioSystem.getAudioInputStream;

public class classB {
    JFrame frameObjB;
    JLabel l = new JLabel();

    JLabel l2 = new JLabel();
    JLabel l1 = new JLabel("ب");

    classB(){
        frameObjB = new JFrame();
        Container C2 = frameObjB.getContentPane();
        C2.setBackground(new Color(166, 65, 217, 255));
        frameObjB.setExtendedState(Frame.MAXIMIZED_BOTH);
        frameObjB.setLayout(null);
        frameObjB.setSize(1540, 820);
        frameObjB.setTitle("FUN ALPHABET");
        frameObjB.setSize(new Dimension(1540, 820));
        frameObjB.setUndecorated(false);
        frameObjB.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 16, 35, 16, Color.white));
        frameObjB.setVisible(true);

        JLabel l3 = new JLabel("بدڪ");
        l3.setForeground(Color.black);
        l3.setFont(new Font("Arial", Font.BOLD, 180));
        l3.setBounds(830,0,380,250);
        l3.setVisible(true);
        C2.add(l3);

        JLabel l4 = new JLabel("بال");
        l4.setForeground(Color.black);
        l4.setFont(new Font("Arial", Font.BOLD, 180));
        l4.setBounds(280,0,380,250);
        l4.setVisible(true);
        C2.add(l4);

        l1.setForeground(Color.black);
        l1.setFont(new Font("Arial", Font.BOLD, 280));
        l1.setBounds(1220,235,190,390);
        l1.setVisible(true);
        C2.add(l1);


        l.setBounds(780, 220, 400, 400);
        l.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\2.jpeg"));
        l.setVisible(true);
        C2.add(l);

        l2.setBounds(180, 220, 400, 400);
        l2.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\b.jpg"));
        l2.setVisible(true);
        C2.add(l2);

        JButton music = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music.setFont(new Font("Arial", Font.BOLD, 18));
        music.setBounds(780, 630, 30, 30);
        frameObjB.add(music);

        music.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\2.wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });

        JButton music2 = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music2.setFont(new Font("Arial", Font.BOLD, 18));
        music2.setBounds(180, 630, 30, 30);
        frameObjB.add(music2);

        music2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\2(1).wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });


        JButton previous = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\previous.jpg"));
        previous.setFont(new Font("Arial", Font.BOLD, 18));
        previous.setBounds(180, 690, 150, 60);
        frameObjB.add(previous);

        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjB.dispose();
                new classC();
            }
        });

        JButton next = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\next.jpg"));
        next.setFont(new Font("Arial", Font.BOLD, 18));
        next.setBounds(1030, 690, 150, 60);
        frameObjB.add(next);

        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjB.dispose();
                new classA();
            }
        });

        JButton back = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\home_btn.png"));
        back.setFont(new Font("Arial", Font.BOLD, 18));
        back.setBounds(25, 20, 60, 60);
        frameObjB.add(back);

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjB.dispose();
                new Fun_Alphabet();
            }
        });
    }
}
