package Fun_Alphabet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class layout {
        JFrame frameObj;

        JLabel l1 = new JLabel("SINDHI ALPHABETS ");

        layout()
        {
            frameObj = new JFrame();
            Container C1 = frameObj.getContentPane();
            l1.setFont(new Font("Algerian", Font.BOLD, 64));
            l1.setBounds(470, 10, 860, 100);
            C1.setBackground(new Color(166, 65, 217, 255));
            l1.setForeground(Color.WHITE);


            JButton b1 = new JButton(" ٿ ");
            b1.setFont(new Font("Arial", Font.BOLD, 18));
            b1.setBounds(110, 100, 150, 60);
            JButton b2 = new JButton("ت ");
            b2.setFont(new Font("Arial", Font.BOLD, 18));
            b2.setBounds(330, 100, 150, 60);
            JButton b3 = new JButton("ڀ");
            b3.setFont(new Font("Arial", Font.BOLD, 18));
            b3.setBounds(550, 100, 150, 60);
            JButton b4 = new JButton("ٻ");
            b4.setFont(new Font("Arial", Font.BOLD, 18));
            b4.setBounds(770, 100, 150, 60);
            JButton b5 = new JButton("ب ");
            b5.setFont(new Font("Arial", Font.BOLD, 18));
            b5.setBounds(990, 100, 150, 60);
            JButton b6 = new JButton("۱");
            b6.setFont(new Font("Arial", Font.BOLD, 18));
            b6.setBounds(1210, 100, 150, 60);


            b6.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classA();
                }
            });

            b5.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classB();
                }
            });

            b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObj.dispose();
                new classC();
            }
        });

            b3.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classD();
                }
            });

            b2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classE();
                }
            });

            b1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classF();
                }
            });

            JButton b7 = new JButton("ڄ");
            b7.setFont(new Font("Arial", Font.BOLD, 18));
            b7.setBounds(110, 170, 150, 60);
            JButton b8 = new JButton("ج");
            b8.setFont(new Font("Arial", Font.BOLD, 18));
            b8.setBounds(330, 170, 150, 60);

            JButton b9 = new JButton("پ ");
            b9.setFont(new Font("Arial", Font.BOLD, 18));
            b9.setBounds(550, 170, 150, 60);
            JButton b10 = new JButton("ث ");
            b10.setBounds(770, 170, 150, 60);
            b10.setFont(new Font("Arial", Font.BOLD, 18));
            JButton b11 = new JButton(" ٺ ");
            b11.setFont(new Font("Arial", Font.BOLD, 18));
            b11.setBounds(990, 170, 150, 60);
            JButton b12 = new JButton(" ٽ  ");
            b12.setFont(new Font("Arial", Font.BOLD, 18));
            b12.setBounds(1210, 170, 150, 60);


            b12.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classG();
                }
            });

            b11.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classH();
                }
            });


            b10.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classI();
                }
            });


            b9.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classJ();
                }
            });


            b8.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classK();
                }
            });


            b7.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classL();
                }
            });


            JButton b13 = new JButton(" خ");
            b13.setFont(new Font("Arial", Font.BOLD, 18));
            b13.setBounds(110, 240, 150, 60);
            JButton b14 = new JButton("ح");
            b14.setFont(new Font("Arial", Font.BOLD, 18));
            b14.setBounds(330, 240, 150, 60);
            JButton b15 = new JButton(" ڇ");
            b15.setFont(new Font("Arial", Font.BOLD, 18));
            b15.setBounds(550, 240, 150, 60);
            JButton b16 = new JButton("چ ");
            b16.setFont(new Font("Arial", Font.BOLD, 18));
            b16.setBounds(770, 240, 150, 60);
            JButton b17 = new JButton("ڃ");
            b17.setFont(new Font("Arial", Font.BOLD, 18));
            b17.setBounds(990, 240, 150, 60);
            JButton b18 = new JButton("جھ");
            b18.setFont(new Font("Arial", Font.BOLD, 18));
            b18.setBounds(1210, 240, 150, 60);



            b18.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classM();
                }
            });


            b17.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classN();
                }
            });

            b16.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new class0();
                }
            });


            b15.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classP();
                }
            });


            b14.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classQ();
                }
            });


            b13.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classR();
                }
            });


            JButton b19 = new JButton("ذ");
            b19.setFont(new Font("Arial", Font.BOLD, 18));
            b19.setBounds(110, 310, 150, 60);
            JButton b20 = new JButton("ڍ");//
            b20.setFont(new Font("Arial", Font.BOLD, 18));
            b20.setBounds(330, 310, 150, 60);
            JButton b21 = new JButton("ڊ ");
            b21.setFont(new Font("Arial", Font.BOLD, 18));
            b21.setBounds(550, 310, 150, 60);
            JButton b22 = new JButton("ڏ");
            b22.setFont(new Font("Arial", Font.BOLD, 18));
            b22.setBounds(770, 310, 150, 60);
            JButton b23 = new JButton(" ڌ");
            b23.setFont(new Font("Arial", Font.BOLD, 18));
            b23.setBounds(990, 310, 150, 60);
            JButton b24 = new JButton(" د");
            b24.setFont(new Font("Arial", Font.BOLD, 18));
            b24.setBounds(1210, 310, 150, 60);


            b24.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classS();
                }
            });

            b23.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classT();
                }
            });

            b22.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classU();
                }
            });


            b21.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classV();
                }
            });


            b20.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classW();
                }
            });


            b19.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classX();
                }
            });



            JButton b25 = new JButton(" ص");
            b25.setFont(new Font("Arial", Font.BOLD, 18));
            b25.setBounds(110, 380, 150, 60);
            JButton b26 = new JButton("ش");
            b26.setFont(new Font("Arial", Font.BOLD, 18));
            b26.setBounds(330, 380, 150, 60);
            JButton b27 = new JButton("س");
            b27.setFont(new Font("Arial", Font.BOLD, 18));
            b27.setBounds(550, 380, 150, 60);
            JButton b28 = new JButton("ز ");
            b28.setFont(new Font("Arial", Font.BOLD, 18));
            b28.setBounds(770, 380, 150, 60);
            JButton b29 = new JButton(" ڙ");
            b29.setFont(new Font("Arial", Font.BOLD, 18));
            b29.setBounds(990, 380, 150, 60);
            JButton b30 = new JButton("ر");
            b30.setFont(new Font("Arial", Font.BOLD, 18));
            b30.setBounds(1210, 380, 150, 60);


            b30.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classY();
                }
            });


            b28.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ1();
                }
            });

            b29.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ();
                }
            });

            b27.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ2();
                }
            });


            b26.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ3();
                }
            });


            b25.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ4();
                }
            });


            JButton b31 = new JButton("ڦ");
            b31.setFont(new Font("Arial", Font.BOLD, 18));
            b31.setBounds(110, 450, 150, 60);
            JButton b32 = new JButton("غ");
            b32.setFont(new Font("Arial", Font.BOLD, 18));
            b32.setBounds(330, 450, 150, 60);
            JButton b33 = new JButton(" ع");
            b33.setFont(new Font("Arial", Font.BOLD, 18));
            b33.setBounds(550, 450, 150, 60);
            JButton b34 = new JButton(" ظ");
            b34.setFont(new Font("Arial", Font.BOLD, 18));
            b34.setBounds(770, 450, 150, 60);
            JButton b35 = new JButton("ط ");
            b35.setFont(new Font("Arial", Font.BOLD, 18));
            b35.setBounds(990, 450, 150, 60);
            JButton b36 = new JButton(" ض ");
            b36.setFont(new Font("Arial", Font.BOLD, 18));
            b36.setBounds(1210, 450, 150, 60);


            b36.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ5();
                }
            });


            b35.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ6();
                }
            });

            b34.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ7();
                }
            });

            b33.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ8();
                }
            });


            b32.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ9();
                }
            });


            b31.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ10();
                }
            });


            JButton b37 = new JButton("ڳ");
            b37.setFont(new Font("Arial", Font.BOLD, 18));
            b37.setBounds(110, 520, 150, 60);
            JButton b38 = new JButton("گھ");
            b38.setFont(new Font("Arial", Font.BOLD, 18));
            b38.setBounds(330, 520, 150, 60);
            JButton b39 = new JButton("گ");
            b39.setFont(new Font("Arial", Font.BOLD, 18));
            b39.setBounds(550, 520, 150, 60);
            JButton b40 = new JButton(" ک");
            b40.setFont(new Font("Arial", Font.BOLD, 18));
            b40.setBounds(770, 520, 150, 60);
            JButton b41 = new JButton("ڪ ");
            b41.setFont(new Font("Arial", Font.BOLD, 18));
            b41.setBounds(990, 520, 150, 60);
            JButton b42 = new JButton(" ق ");
            b42.setFont(new Font("Arial", Font.BOLD, 18));
            b42.setBounds(1210, 520, 150, 60);


            b42.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ11();
                }
            });


            b41.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ12();
                }
            });


            b40.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ13();
                }
            });


            b39.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ14();
                }
            });


            b38.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ15();
                }
            });


            b37.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ16();
                }
            });

            ////
            JButton b43 = new JButton("ف ");
            b43.setFont(new Font("Arial", Font.BOLD, 18));
            b43.setBounds(110, 590, 150, 60);
            JButton b44 = new JButton("ڻ");
            b44.setFont(new Font("Arial", Font.BOLD, 18));
            b44.setBounds(330, 590, 150, 60);
            JButton b45 = new JButton(" ن");
            b45.setFont(new Font("Arial", Font.BOLD, 18));
            b45.setBounds(550, 590, 150, 60);
            JButton b46 = new JButton("م ");
            b46.setFont(new Font("Arial", Font.BOLD, 18));
            b46.setBounds(770, 590, 150, 60);
            JButton b47 = new JButton("ل ");
            b47.setFont(new Font("Arial", Font.BOLD, 18));
            b47.setBounds(990, 590, 150, 60);
            JButton b48 = new JButton("  ڱ");
            b48.setFont(new Font("Arial", Font.BOLD, 18));
            b48.setBounds(1210, 590, 150, 60);


            b48.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ17();
                }
            });


            b47.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ18();
                }
            });


            b46.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ19();
                }
            });


            b45.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ20();
                }
            });


            b44.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ21();
                }
            });


            b43.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ22();
                }
            });


            ////
            JButton b49 = new JButton(" ى");
            b49.setFont(new Font("Arial", Font.BOLD, 18));
            b49.setBounds(330, 660, 150, 60);
            JButton b50 = new JButton("ء ");
            b50.setFont(new Font("Arial", Font.BOLD, 18));
            b50.setBounds(550, 660, 150, 60);
            JButton b51 = new JButton("ھ");
            b51.setFont(new Font("Arial", Font.BOLD, 18));
            b51.setBounds(770, 660, 150, 60);
            JButton b52 = new JButton("و ");
            b52.setFont(new Font("Arial", Font.BOLD, 18));
            b52.setBounds(990, 660, 150, 60);




            b52.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ23();
                }
            });


            b51.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ24();
                }
            });

            b49.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ26();
                }
            });

            b50.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameObj.dispose();
                    new classZ25();
                }
            });

//        // adding buttons to the frame
            frameObj.add(l1);
            frameObj.add(b1);
            frameObj.add(b2);
            frameObj.add(b3);
            frameObj.add(b4);
            frameObj.add(b5);
            frameObj.add(b6);
            frameObj.add(b7);
            frameObj.add(b8);
            frameObj.add(b9);
            frameObj.add(b10);
            frameObj.add(b11);
            frameObj.add(b12);
            frameObj.add(b13);
            frameObj.add(b14);
            frameObj.add(b15);
            frameObj.add(b16);
            frameObj.add(b17);
            frameObj.add(b18);
            frameObj.add(b19);
            frameObj.add(b20);
            frameObj.add(b21);
            frameObj.add(b22);
            frameObj.add(b23);
            frameObj.add(b24);
            frameObj.add(b25);
            frameObj.add(b26);
            frameObj.add(b27);
            frameObj.add(b28);
            frameObj.add(b29);
            frameObj.add(b30);
            frameObj.add(b31);
            frameObj.add(b32);
            frameObj.add(b33);
            frameObj.add(b34);
            frameObj.add(b35);
            frameObj.add(b36);
            frameObj.add(b37);
            frameObj.add(b38);
            frameObj.add(b39);
            frameObj.add(b40);
            frameObj.add(b41);
            frameObj.add(b42);
            frameObj.add(b43);
            frameObj.add(b44);
            frameObj.add(b45);
            frameObj.add(b46);
            frameObj.add(b47);
            frameObj.add(b48);
            frameObj.add(b49);
            frameObj.add(b50);
            frameObj.add(b51);
            frameObj.add(b52);

            // setting layout of frame
            frameObj.setLayout(null);
            frameObj.setSize(1540, 820);
            frameObj.setTitle("FUN ALPHABET");
            frameObj.setSize(new Dimension(1540, 820));
            frameObj.setExtendedState(Frame.MAXIMIZED_BOTH);
            frameObj.setUndecorated(false);
            frameObj.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 20, 35, 20, Color.white));
            frameObj.setVisible(true);

//

            frameObj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        }
    }

