package Fun_Alphabet;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import static javax.sound.sampled.AudioSystem.getAudioInputStream;

public class classZ21 {

    JFrame frameObjZ21;
        JLabel l2 = new JLabel();
    JLabel l = new JLabel();
    JLabel l1 = new JLabel("ڻ");

    classZ21(){
        frameObjZ21 = new JFrame();
        Container C2 = frameObjZ21.getContentPane();
        C2.setBackground(new Color(166, 65, 217, 255));
        frameObjZ21.setLayout(null);
        frameObjZ21.setExtendedState(Frame.MAXIMIZED_BOTH);
        frameObjZ21.setSize(1540, 820);
        frameObjZ21.setTitle("FUN ALPHABET");
        frameObjZ21.setSize(new Dimension(1540, 820));
        frameObjZ21.setUndecorated(false);
        frameObjZ21.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 16, 35, 16, Color.white));
        frameObjZ21.setVisible(true);

        l1.setForeground(Color.black);
        l1.setFont(new Font("Arial", Font.BOLD, 280));
        l1.setBounds(1220,210,190,390);
        l1.setVisible(true);
        C2.add(l1);

        JLabel l3 = new JLabel("وڻ");
        l3.setForeground(Color.black);
        l3.setFont(new Font("Arial", Font.BOLD, 180));
        l3.setBounds(880,0,380,230);
        l3.setVisible(true);
        C2.add(l3);

        JLabel l4 = new JLabel("واڱڻ");
        l4.setForeground(Color.black);
        l4.setFont(new Font("Arial", Font.BOLD, 180));
        l4.setBounds(250,0,380,230);
        l4.setVisible(true);
        C2.add(l4);

        l.setBounds(780, 220, 400, 400);
        l.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\49.jpg"));
        l.setVisible(true);
        C2.add(l);

        JButton music = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music.setFont(new Font("Arial", Font.BOLD, 18));
        music.setBounds(780, 630, 30, 30);
        frameObjZ21.add(music);

        music.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\47.wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });

        JButton music2 = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\music.jpg"));
        music2.setFont(new Font("Arial", Font.BOLD, 18));
        music2.setBounds(180, 630, 30, 30);
        frameObjZ21.add(music2);

        music2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\audio\\47(1).wav");
                AudioInputStream audioStream = null;
                try {
                    audioStream = getAudioInputStream(file);
                } catch (UnsupportedAudioFileException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                Clip clip = null;
                try {
                    clip = AudioSystem.getClip();
                } catch (LineUnavailableException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    clip.open(audioStream);
                } catch (LineUnavailableException | IOException ex) {
                    throw new RuntimeException(ex);
                }
                clip.start();
            }
        });

        JButton previous = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\previous.jpg"));
        previous.setFont(new Font("Arial", Font.BOLD, 18));
        previous.setBounds(180, 690, 150, 60);
        frameObjZ21.add(previous);

        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjZ21.dispose();
                new classZ22();
            }
        });

        JButton next = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\next.jpg"));
        next.setFont(new Font("Arial", Font.BOLD, 18));
        next.setBounds(1030, 690, 150, 60);
        frameObjZ21.add(next);

        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjZ21.dispose();
                new classZ20();
            }
        });

        l2.setBounds(180, 220, 400, 400);
        l2.setIcon(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\47.jpg"));
        l2.setVisible(true);
        C2.add(l2);

        JButton back = new JButton(new ImageIcon("C:\\Users\\sagar\\IdeaProjects\\FUN_PROJECT\\image\\home_btn.png"));
        back.setFont(new Font("Arial", Font.BOLD, 18));
        back.setBounds(25, 20, 60, 60);
        frameObjZ21.add(back);

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameObjZ21.dispose();
                new Fun_Alphabet();
            }
        });
    }
}
